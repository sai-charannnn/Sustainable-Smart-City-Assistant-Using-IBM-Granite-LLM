from fastapi import FastAPI
from dotenv import load_dotenv
import os

from app.api import assistant, finder, dashboard, alerts, policy

load_dotenv()

app = FastAPI(title="Sustainable Smart City Assistant")

# Include routers from each module
app.include_router(assistant.router, prefix="/assistant", tags=["Assistant"])
app.include_router(finder.router, prefix="/finder", tags=["Finder"])
app.include_router(dashboard.router, prefix="/dashboard", tags=["Dashboard"])
app.include_router(alerts.router, prefix="/alerts", tags=["Alerts"])
app.include_router(policy.router, prefix="/policy", tags=["Policy"])

@app.get("/")
async def root():
    return {"message": "✅ Smart City Assistant API running successfully!"}
