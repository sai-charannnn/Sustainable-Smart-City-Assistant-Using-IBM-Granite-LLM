import requests
from app.core.config import IBM_API_KEY, IBM_API_URL

def ask_ibm_assistant(question):
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {IBM_API_KEY}"
    }
    payload = {
        "prompt": question,
        "model": "granite-2b-instruct"
    }
    response = requests.post(IBM_API_URL, headers=headers, json=payload)
    return response.json()
