from dotenv import load_dotenv
import os

# Load environment variables from .env file
load_dotenv()

IBM_API_KEY = os.getenv("IBM_API_KEY")
IBM_API_URL = os.getenv("IBM_API_URL")