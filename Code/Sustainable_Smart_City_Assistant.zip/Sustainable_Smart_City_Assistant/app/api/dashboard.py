from fastapi import APIRouter

router = APIRouter()

@router.get("/emissions")
async def get_emissions_data():
    return {"carbon_emissions": "1200 tons CO₂", "recycling_rate": "35%"}
