from fastapi import APIRouter

router = APIRouter()

@router.get("/policy-info")
async def get_policy_summary():
    return {"summary": "City Climate Plan aims to reduce emissions by 40% by 2030."}
