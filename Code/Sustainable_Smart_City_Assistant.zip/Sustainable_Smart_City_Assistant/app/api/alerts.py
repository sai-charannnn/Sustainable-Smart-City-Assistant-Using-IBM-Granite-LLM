from fastapi import APIRouter

router = APIRouter()

@router.get("/waste-reminder")
async def get_waste_pickup_reminder():
    return {"message": "Your next waste pickup is tomorrow at 7 AM"}
