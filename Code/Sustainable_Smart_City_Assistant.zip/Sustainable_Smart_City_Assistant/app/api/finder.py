from fastapi import APIRouter

router = APIRouter()

@router.get("/ev-locator")
async def get_ev_locations():
    return {"locations": ["EV Station 1", "EV Station 2"]}
